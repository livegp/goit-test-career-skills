import{j as r}from"./index-ft7c1fMM.js";function e(){return r.jsx("h2",{children:" Favorites "})}export{e as default};
