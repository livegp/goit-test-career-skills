import{s as a,j as r}from"./index-ft7c1fMM.js";const o=a.div`
  height: 100%;
  width: 100%;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  background-position: 25% 75%;
  background-size: cover;
  background-clip: border-box;
  background-origin: border-box;
  background-image: linear-gradient(
      to right,
      rgba(var(--bg-primary), 1),
      rgba(var(--bg-primary), 0.7),
      rgba(var(--bg-primary), 0)
    ),
    url('./img/avtomobili.webp');

  background-repeat: no-repeat;
`,t=a.h1`
  font-size: 40px;
  font-weight: bold;
  color: rgba(var(--accent), 1);
  transition: var(--trans);
`;function e(){return r.jsx(o,{children:r.jsxs(t,{children:["Find the car ",r.jsx("br",{})," of your dreams"]})})}export{e as default};
